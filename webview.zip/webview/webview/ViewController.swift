//
//  ViewController.swift
//  webview
//
//  Created by MACOS on 11/19/16.
//  Copyright © 2016 surat. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var web: UIWebView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
     //   let url = URL(string: "http://www.topsint.com/topserp/index.php?lg=1");
        var str = String()
        str = Bundle.main.path(forResource: "Convocation", ofType: "pdf")!
        
        let url1 = URL(string: str);
        web.loadRequest(URLRequest(url: url1!))
        // Do any additional setup after loading the view, typically from a nib.
    }

    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

